package com.example.NgoDetailsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgoDetailsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
