package com.example.MyCtsProjectGateWay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyCtsProjectGateWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
