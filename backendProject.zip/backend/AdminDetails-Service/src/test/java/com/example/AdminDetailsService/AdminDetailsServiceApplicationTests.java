package com.example.AdminDetailsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminDetailsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
