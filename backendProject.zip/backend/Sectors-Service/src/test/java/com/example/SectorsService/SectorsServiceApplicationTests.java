package com.example.SectorsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SectorsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
