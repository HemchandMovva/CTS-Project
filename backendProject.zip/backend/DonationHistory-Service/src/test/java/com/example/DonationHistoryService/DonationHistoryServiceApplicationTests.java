package com.example.DonationHistoryService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonationHistoryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
