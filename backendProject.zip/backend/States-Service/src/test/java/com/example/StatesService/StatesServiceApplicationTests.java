package com.example.StatesService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
