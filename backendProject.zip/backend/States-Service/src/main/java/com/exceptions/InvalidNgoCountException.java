package com.exceptions;

public class InvalidNgoCountException extends Exception {

	public InvalidNgoCountException(String message) {
		super(message);
	}
}
