package com.exceptions;

@SuppressWarnings("serial")
public class InvalidFundException extends Exception {

	public InvalidFundException(String str) {
		super(str);
	}
}
