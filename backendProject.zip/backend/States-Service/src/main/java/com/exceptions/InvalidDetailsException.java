package com.exceptions;

public class InvalidDetailsException extends Exception {

	public InvalidDetailsException(String message) {
		super(message);
	}
}
